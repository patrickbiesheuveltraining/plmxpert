﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert2
{
    internal class DataHandler
    {
        public ObservableCollection<ConfigurationModel> ReadConfigurations()
        {
            ObservableCollection<ConfigurationModel> list = new ObservableCollection<ConfigurationModel>();
            list.Add(new ConfigurationModel() { TableName = "Test1", DisplayName = "Test2" });
            list.Add(new ConfigurationModel() { TableName = "Test10", DisplayName = "Test20" });
            list.Add(new ConfigurationModel() { TableName = "Test100", DisplayName = "Test200" });
            return list;
        }

        public ObservableCollection<TableModel> ReadTables()
        {
            ObservableCollection<TableModel> list = new ObservableCollection<TableModel>();
            return list;
        }
    }
}