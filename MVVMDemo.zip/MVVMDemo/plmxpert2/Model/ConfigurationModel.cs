﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert2
{
    internal class ConfigurationModel
    {
        public string TableName { get; set; }
        public string DisplayName { get; set; }
        public bool Edit { get; set; }
        public bool Add { get; set; }
        public bool Duplicate { get; set; }
        public bool Delete { get; set; }
        public string DefaultSortColumn { get; set; }
        public string RowIdentifier { get; set; }
    }
}
