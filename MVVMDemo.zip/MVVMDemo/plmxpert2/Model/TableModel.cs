﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert2
{
    internal class TableModel
    {
        public string Name { get; set; }
        public List<string> Columns { get; set; }
    }
}
