﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert2
{
    internal class MainViewModel:ViewModelBase
    {
        private DataHandler _handler;
        private ObservableCollection<ConfigurationModel> _configurations;
        private ObservableCollection<TableModel> _tableModels;

        public ObservableCollection<ConfigurationModel> Configurations 
        { get { return _configurations; } }

        public MainViewModel()
        {
            _handler = new DataHandler();
            _configurations = _handler.ReadConfigurations();
            _tableModels = _handler.ReadTables();
        }
    }
}
