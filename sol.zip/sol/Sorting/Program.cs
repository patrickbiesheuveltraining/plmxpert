﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Apple> fruitschaal = new List<Apple>();    
            fruitschaal.Add(new Apple( "Jonagold", 100, "geel"));
            fruitschaal.Add(new Apple( "Jonagold", 200, "geel" ));
            fruitschaal.Add(new Apple( "Kanzi", 150, "rood" ));
            fruitschaal.Add(new Apple( "Elstar", 170, "oranje" ));
            fruitschaal.Add(new Apple( "Elstar", 120, "oranje" ));

            fruitschaal.Sort();
            foreach ( var item in fruitschaal)
            {
                Console.WriteLine(item.ToString() );
                
            }

        }
    }
}
