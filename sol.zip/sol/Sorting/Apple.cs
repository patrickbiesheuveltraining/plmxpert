﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Sorting
{
    internal class Apple:IComparable<Apple>
    {
        public string Name { get;set; }
        public int Weight {  get;set; } 
        public string Color { get;set; }

        public override string ToString()
        {
            return $"Apple with {Name}, {Weight} and {Color}.";
        }

        public int CompareTo(Apple other)
        {
            //return this.Weight - other.Weight;
            return Color.CompareTo(other.Color) ;
        }

        public Apple(string name, int weight, string color)
        {
            Name = name ;
            Weight = weight ;
            Color = color ; 
        }
    }
}
