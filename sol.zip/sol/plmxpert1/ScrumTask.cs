﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert1
{
    internal class ScrumTask:IMessageBoardPost
    {
        private DateTime _postDate;
        public DateTime PostDate { 
            get { return _postDate; }
            set { _postDate = value; }
        }

        public string MessageBoardToString()
        {
            return "Scrum message";
        }

        public ScrumTask()
        {
             PostDate = DateTime.Now;   
        }

        public int CompareTo(IMessageBoardPost other)
        {
            return PostDate.CompareTo(other.PostDate);
        }
    }
}
