﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Post myPost = new Post("1","Memo",text:"hallo allemaal");
            //Console.WriteLine(myPost.Text);

            ReviewPost myReview = new ReviewPost(90,"2", "Review Nietmachine", "Heel fijn");
            ScrumTask myScrum = new ScrumTask();

            MessageBoard myBoard = new MessageBoard();
            myBoard.NewPost(myPost);
            myBoard.NewPost(myReview);
            myBoard.NewPost(myScrum);
            myBoard.ViewBoard();
        }
    }
}
