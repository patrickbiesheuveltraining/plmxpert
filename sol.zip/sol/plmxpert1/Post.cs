﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert1
{
    internal class Post:IMessageBoardPost
    {
        private string _id;
        //private string _title;
        //private string _text;
        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Title { get; set; }
        public string Text { get; set; }

        public DateTime PostDate { get; set; }  

        //public Post():this("nb", "nb", "nb")
        //{
        //    Console.WriteLine("default ctor");
        //}
        public Post(string id = "nb", string title = "nb", string text = "nb")
        {
            Id = id;
            Title = title;
            Text = text;
            PostDate = DateTime.Now;    
        }

        public virtual string MessageBoardToString()
        {
            return $"<{Id}> {Title}\n{Text}";
        }

        public int CompareTo(IMessageBoardPost other)
        {
            return PostDate.CompareTo(other.PostDate);
        }
    }
}
