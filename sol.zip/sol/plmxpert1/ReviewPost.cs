﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert1
{
    internal class ReviewPost:Post
    {
        public int Score { get; set; }

        public ReviewPost( int score = 50,string id = "nb", string title = "nb", string text = "nb")
              :base(id, title, text)
        {
            Title = "Review";
            Score = score;
        }

        public override string MessageBoardToString()
        {
            return $"<{Id}> {Title} <{Score}/100>\n{Text}";
        }
    }
}
