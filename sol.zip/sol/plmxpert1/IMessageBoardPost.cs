﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert1
{
    internal interface IMessageBoardPost:IComparable<IMessageBoardPost>
    {
        DateTime PostDate { get; set; }  
        string MessageBoardToString();
    }
}
