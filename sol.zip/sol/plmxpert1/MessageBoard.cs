﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plmxpert1
{
    internal class MessageBoard
    {
        private List<IMessageBoardPost> posts;

        public MessageBoard()
        {
            posts = new List<IMessageBoardPost>();   
        }
        public void NewPost(IMessageBoardPost newPost)
        {
            posts.Add(newPost); 
        }

        public void ViewBoard()
        {
            posts.Sort();
            foreach (var post in posts) 
            {
                Console.WriteLine(post.PostDate);
                Console.WriteLine(post.MessageBoardToString()  );
                
            }
        }
    }
}
